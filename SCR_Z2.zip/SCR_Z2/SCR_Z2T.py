import time
import tkinter as tk
from tkinter import messagebox

def calculate_crc(data):
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc >>= 1
                crc ^= 0xA001
            else:
                crc >>= 1
    return crc

def execute_algorithm():
    try:
        hex_sequence = hex_entry.get()
        byte_sequence = bytearray.fromhex(hex_sequence.replace(" ", ""))
        if len(byte_sequence) > 256:
            messagebox.showerror("Błąd", "Maksymalna długość sekwencji to 256 bajtów.")
            return

        repetitions = int(repetitions_entry.get())
        if not 1 <= repetitions <= 1000000000:
            messagebox.showerror("Błąd", "Liczba powtórzeń powinna być z zakresu 1-10^9.")
            return

        start_time = round(time.time(), 13)
        crc_result = calculate_crc(byte_sequence)
        end_time = round(time.time(), 13)
        execution_time = (end_time - start_time) * 1000  # czas w [ms]

        result_text = f"Wartość CRC: {crc_result:04X}\nŁączny czas realizacji {repetitions} powtórzeń: {execution_time} ms"
        result_label.config(text=result_text)

    except ValueError:
        messagebox.showerror("Błąd", "Nieprawidłowe dane wejściowe.")

# Tworzenie głównego okna
root = tk.Tk()
root.title("Obliczanie CRC")

# Etykiety i pola do wprowadzania danych
hex_label = tk.Label(root, text="Podaj sekwencję bajtów w notacji heksadecymalnej (oddzielone spacją):")
hex_label.pack()
hex_entry = tk.Entry(root)
hex_entry.pack()

repetitions_label = tk.Label(root, text="Podaj liczbę powtórzeń algorytmu (1-10^9):")
repetitions_label.pack()
repetitions_entry = tk.Entry(root)
repetitions_entry.pack()

execute_button = tk.Button(root, text="Wykonaj", command=execute_algorithm)
execute_button.pack()

result_label = tk.Label(root, text="")
result_label.pack()

root.mainloop()
