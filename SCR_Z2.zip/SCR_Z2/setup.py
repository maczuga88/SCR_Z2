from cx_Freeze import setup, Executable

setup(
    name="SCR_Z2_DM303159",
    version="1.0",
    executables=[Executable("SCR_Z2T.py")]
)
